package com.psl.db.repository;  
import org.springframework.data.repository.CrudRepository;

import com.psl.db.model.UserRecord;  
public interface UserRepository extends CrudRepository<UserRecord, String> 
{  
	//Default operations from CrudRepository will be avaialble for e.g. save(), findAll() etc.
}  
