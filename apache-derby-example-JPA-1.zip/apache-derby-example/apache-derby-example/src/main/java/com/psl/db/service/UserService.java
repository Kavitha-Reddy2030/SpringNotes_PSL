package com.psl.db.service;

import java.util.List;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.psl.db.model.UserRecord;
import com.psl.db.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;

	//Fetch information of the users. 
	//We are using a default method from crudRepository called as findAll() = > equal to select all user records.
	public List<UserRecord> getAllUsers() {
		List<UserRecord> userRecords = new ArrayList<>();
		userRepository.findAll().forEach(userRecords::add);
		return userRecords;
	}

	//Operation 1 - > Add a user 
	//I will have an object called as userRecord 
	//UserRecord is an Entity that will be Saved.
	public void addUser(UserRecord userRecord) {
		userRepository.save(userRecord);//Default crud repository method save()
	}
}