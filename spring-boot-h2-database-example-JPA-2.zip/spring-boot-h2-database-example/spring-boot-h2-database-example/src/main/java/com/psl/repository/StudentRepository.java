package com.psl.repository;

import org.springframework.data.repository.CrudRepository;

import com.psl.model.Student;

public interface StudentRepository extends CrudRepository<Student, Integer> {
}
