package com.psl.some.mypackage;

public class Class2 {

}
