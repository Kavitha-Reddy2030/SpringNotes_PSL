package com.psl.some.mypackage.test;
import com.psl.some.mypackage.*;
public class SampleTestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//I want something where in i can just fetch object of all the classes in com.psl.some.mypackage 
		Class1 c1 = new Class1();
		Class2 c2 = new Class2();
		Class3 c3 = new Class3();
		//What if there are 300 classes.
	}

}
