package com.psl.some.mypackage;

public class Class1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
